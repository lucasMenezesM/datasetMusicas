import java.util.Scanner;

public class ProgramaMusica {
    public static void main(String args[]){
        Scanner inputData = new Scanner(System.in);
        String filePath = "A:\\Conteudo Faculdade\\3º Período\\Técnicas de programação\\leituraArquivos\\Song.csv";
        VetorDeMusicas vetorMusicas = new VetorDeMusicas();

        ManipulaDataSet.lerDoArquivoCSV(vetorMusicas, filePath);
        ManipulaDataSet.escreverNoArquivoCSV(vetorMusicas);

        System.out.println("Qual funcionalidade gostaria de realizar?");
        System.out.println("1- Adição de músicas\n2- Exclusão de músicas\n3- Troca de posição de músicas\n4- Alterar uma música\n5- Finalizar programa");
        int funcionalidade = inputData.nextInt();
        
        switch (funcionalidade) {
            case 1:
                inputData.nextLine();
                System.out.println("Digite as informações da nova música a seguir:\n");
                System.out.printf("Digite nome do artista: ");
                String artist = inputData.nextLine();

                System.out.printf("Digite nome do título: ");
                String title = inputData.nextLine();

                System.out.printf("Digite nome do ano: ");
                String year = inputData.nextLine();

                System.out.printf("Digite número de vendas: ");
                String sales = inputData.nextLine();

                System.out.printf("Digite o rating da música: ");
                String rating = inputData.nextLine();

                System.out.printf("Digite o número de streams da música: ");
                String streams = inputData.nextLine();

                Musica novaMusica = new Musica(artist, title, year, sales, rating, streams);
                vetorMusicas.adicionarMusica(novaMusica);

                System.out.printf("Música %s adicionada!", novaMusica.getTitle());
                break;
            
            case 2:
                System.out.println(funcionalidade+" selecionada");
                System.out.println("Qual a posição da música que deseja excluir?");
                int posicao = inputData.nextInt();

                System.out.println("Antes da exclusão: "+ vetorMusicas.obterTotalMusicas());

                if(posicao < 0 || posicao > vetorMusicas.obterTotalMusicas()){
                    System.out.println("Posição inválida.");
                    break;
                }

                Musica musicaExcluida = vetorMusicas.obterMusica(posicao);
                vetorMusicas.excluirMusica(musicaExcluida);
                System.out.println("Depois da exclusão: "+vetorMusicas.obterTotalMusicas());

                break;

            case 3:
                System.out.println("Quais as posições que gostaria de trocar?");
                int posicao1 = inputData.nextInt();
                int posicao2 = inputData.nextInt();
                
                vetorMusicas.trocarPosicaoMusicas(posicao1, posicao2);
                break;

            case 4:
                System.out.println("Qual a posição da música a ser alterada?");
                int posicaoAlteracao = inputData.nextInt();

                System.out.println("Digite as informações atualizadas a seguir:\n");

                System.out.printf("Digite nome do artista: ");
                String newArtist = inputData.nextLine();

                System.out.printf("Digite nome do título: ");
                String newTitle = inputData.nextLine();

                System.out.printf("Digite nome do ano: ");
                String newYear = inputData.nextLine();

                System.out.printf("Digite número de vendas: ");
                String newSales = inputData.nextLine();

                System.out.printf("Digite o rating da música: ");
                String newRating = inputData.nextLine();

                System.out.printf("Digite o número de streams da música: ");
                String newStreams = inputData.nextLine();

                Musica musicaAlterada = new Musica(newArtist, newTitle, newYear, newSales, newRating, newStreams);
                
                vetorMusicas.alterarMusica(posicaoAlteracao, musicaAlterada);
                break;
        
            case 5:
                System.out.println("Programa finalizado.");
                break;

            default:
                System.out.println("Opção não reconhecida");
                break;
        }
       
        inputData.close();
        // listar(vetorMusicas);
        // System.out.println(vetorMusicas.getQuantidadeMusicas());

        // System.out.println(vetorMusicas.obterMusica(vetorMusicas.obterTotalMusicas() - 1).getTitle());
        System.out.println("quantidade: "+vetorMusicas.obterTotalMusicas());
       
    }

    public void listar(ColecaoDeMusicas colecao){
        for(int i = 0; i < colecao.obterTotalMusicas() ; i++){
            System.out.println(colecao.obterMusica(i).getTitle());
        }
    }

}
